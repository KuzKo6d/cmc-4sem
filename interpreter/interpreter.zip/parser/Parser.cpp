#include "Parser.h"

#include <stdexcept>
#include <vector>

class ParserImpl {
private:
    std::vector<Token>& tokens;
    size_t& pos;

public:
    ParserImpl(
        std::vector<Token>& tokens,
        size_t& pos
    )
        : tokens(tokens),
          pos(pos) {}

    Token& current() {
        return tokens[pos];
    }

    bool match(TokenType type) {
        if (current().type == type) {
            pos++;
            return true;
        }

        return false;
    }

    void expect(TokenType type) {
        if (!match(type)) {
            throw std::runtime_error(
                "Unexpected token"
            );
        }
    }

    //
    // EXPRESSIONS
    //

    std::unique_ptr<Expression>
    parseExpression() {
        return parseOr();
    }

    std::unique_ptr<Expression>
    parseOr() {

        auto left = parseAnd();

        while (match(TokenType::KW_OR)) {

            auto right = parseAnd();

            left =
                std::make_unique<
                    BinaryExpression
                >(
                    BinaryOp::OR,
                    std::move(left),
                    std::move(right)
                );
        }

        return left;
    }

    std::unique_ptr<Expression>
    parseAnd() {

        auto left = parseEquality();

        while (match(TokenType::KW_AND)) {

            auto right =
                parseEquality();

            left =
                std::make_unique<
                    BinaryExpression
                >(
                    BinaryOp::AND,
                    std::move(left),
                    std::move(right)
                );
        }

        return left;
    }

    std::unique_ptr<Expression>
    parseEquality() {

        auto left =
            parseRelational();

        while (true) {

            if (match(TokenType::EQ)) {

                auto right =
                    parseRelational();

                left =
                    std::make_unique<
                        BinaryExpression
                    >(
                        BinaryOp::EQ,
                        std::move(left),
                        std::move(right)
                    );
            }
            else {
                break;
            }
        }

        return left;
    }

    std::unique_ptr<Expression>
    parseRelational() {

        auto left =
            parseAdditive();

        while (true) {

            if (match(TokenType::LT)) {

                auto right =
                    parseAdditive();

                left =
                    std::make_unique<
                        BinaryExpression
                    >(
                        BinaryOp::LT,
                        std::move(left),
                        std::move(right)
                    );
            }
            else if (match(TokenType::GT)) {

                auto right =
                    parseAdditive();

                left =
                    std::make_unique<
                        BinaryExpression
                    >(
                        BinaryOp::GT,
                        std::move(left),
                        std::move(right)
                    );
            }
            else {
                break;
            }
        }

        return left;
    }

    std::unique_ptr<Expression>
    parseAdditive() {

        auto left =
            parseMultiplicative();

        while (true) {

            if (match(TokenType::PLUS)) {

                auto right =
                    parseMultiplicative();

                left =
                    std::make_unique<
                        BinaryExpression
                    >(
                        BinaryOp::PLUS,
                        std::move(left),
                        std::move(right)
                    );
            }
            else if (
                match(TokenType::MINUS)
            ) {

                auto right =
                    parseMultiplicative();

                left =
                    std::make_unique<
                        BinaryExpression
                    >(
                        BinaryOp::MINUS,
                        std::move(left),
                        std::move(right)
                    );
            }
            else {
                break;
            }
        }

        return left;
    }

    std::unique_ptr<Expression>
    parseMultiplicative() {

        auto left = parseUnary();

        while (true) {

            if (match(TokenType::MUL)) {

                auto right =
                    parseUnary();

                left =
                    std::make_unique<
                        BinaryExpression
                    >(
                        BinaryOp::MUL,
                        std::move(left),
                        std::move(right)
                    );
            }
            else if (
                match(TokenType::DIV)
            ) {

                auto right =
                    parseUnary();

                left =
                    std::make_unique<
                        BinaryExpression
                    >(
                        BinaryOp::DIV,
                        std::move(left),
                        std::move(right)
                    );
            }
            else {
                break;
            }
        }

        return left;
    }

    std::unique_ptr<Expression>
    parseUnary() {

        if (match(TokenType::PLUS)) {

            return
                std::make_unique<
                    UnaryExpression
                >(
                    UnaryOp::PLUS,
                    parseUnary()
                );
        }

        if (match(TokenType::MINUS)) {

            return
                std::make_unique<
                    UnaryExpression
                >(
                    UnaryOp::MINUS,
                    parseUnary()
                );
        }

        if (match(TokenType::KW_NOT)) {

            return
                std::make_unique<
                    UnaryExpression
                >(
                    UnaryOp::NOT,
                    parseUnary()
                );
        }

        return parsePrimary();
    }

    std::unique_ptr<Expression>
    parsePrimary() {

        if (match(TokenType::INT_LITERAL)) {

            return
                std::make_unique<
                    LiteralExpression
                >(
                    Value::makeInt(
                        std::stoi(
                            tokens[pos - 1].text
                        )
                    )
                );
        }

        if (
            match(TokenType::STRING_LITERAL)
        ) {

            return
                std::make_unique<
                    LiteralExpression
                >(
                    Value::makeString(
                        tokens[pos - 1].text
                    )
                );
        }

        if (
            match(TokenType::BOOL_LITERAL)
        ) {

            return
                std::make_unique<
                    LiteralExpression
                >(
                    Value::makeBool(
                        tokens[pos - 1].text
                        == "true"
                    )
                );
        }

        if (
            match(TokenType::IDENTIFIER)
        ) {

            return
                std::make_unique<
                    VariableExpression
                >(
                    tokens[pos - 1].text
                );
        }

        if (match(TokenType::LPAREN)) {

            auto expr =
                parseExpression();

            expect(TokenType::RPAREN);

            return expr;
        }

        throw std::runtime_error(
            "Invalid expression"
        );
    }

    //
    // STATEMENTS
    //

    std::unique_ptr<BlockStatement>
    parseBlock() {

        expect(TokenType::LBRACE);

        auto block =
            std::make_unique<
                BlockStatement
            >();

        while (
            current().type
            != TokenType::RBRACE
        ) {

            block->add(
                parseStatement()
            );
        }

        expect(TokenType::RBRACE);

        return block;
    }

    std::unique_ptr<Statement>
    parseStatement() {

        //
        // int x;
        //

        if (match(TokenType::KW_INT)) {

            expect(
                TokenType::IDENTIFIER
            );

            std::string name =
                tokens[pos - 1].text;

            expect(
                TokenType::SEMICOLON
            );

            return
                std::make_unique<
                    VariableDeclarationStatement
                >(
                    name,
                    ValueType::INT
                );
        }

        //
        // continue;
        //

        if (
            match(TokenType::KW_CONTINUE)
        ) {

            expect(
                TokenType::SEMICOLON
            );

            return
                std::make_unique<
                    ContinueStatement
                >();
        }

        //
        // write(...)
        //

        if (
            match(TokenType::KW_WRITE)
        ) {

            expect(TokenType::LPAREN);

            std::vector<
                std::unique_ptr<
                    Expression
                >
            > expressions;

            expressions.push_back(
                parseExpression()
            );

            while (
                match(TokenType::COMMA)
            ) {

                expressions.push_back(
                    parseExpression()
                );
            }

            expect(TokenType::RPAREN);

            expect(
                TokenType::SEMICOLON
            );

            return
                std::make_unique<
                    WriteStatement
                >(
                    std::move(
                        expressions
                    )
                );
        }

        //
        // if (...)
        //

        if (match(TokenType::KW_IF)) {

            expect(TokenType::LPAREN);

            auto condition =
                parseExpression();

            expect(TokenType::RPAREN);

            auto thenStmt =
                parseStatement();

            return
                std::make_unique<
                    IfStatement
                >(
                    std::move(
                        condition
                    ),
                    std::move(
                        thenStmt
                    ),
                    nullptr
                );
        }

        //
        // for
        //

        if (match(TokenType::KW_FOR)) {

            expect(
                TokenType::IDENTIFIER
            );

            std::string var =
                tokens[pos - 1].text;

            expect(TokenType::ASSIGN);

            auto start =
                parseExpression();

            expect(TokenType::KW_STEP);

            auto step =
                parseExpression();

            expect(
                TokenType::KW_UNTIL
            );

            auto until =
                parseExpression();

            expect(TokenType::KW_DO);

            auto body =
                parseStatement();

            return
                std::make_unique<
                    ForStatement
                >(
                    var,
                    std::move(start),
                    std::move(step),
                    std::move(until),
                    std::move(body)
                );
        }

        //
        // case
        //

        if (
            match(TokenType::KW_CASE)
        ) {

            expect(TokenType::LPAREN);

            auto expr =
                parseExpression();

            expect(TokenType::RPAREN);

            expect(TokenType::KW_OF);

            std::vector<
                CaseBranch
            > branches;

            while (
                current().type
                != TokenType::KW_END
            ) {

                CaseBranch branch;

                expect(
                    TokenType::INT_LITERAL
                );

                branch.constants.push_back(
                    std::stoi(
                        tokens[pos - 1].text
                    )
                );

                expect(TokenType::COLON);

                branch.statement =
                    parseStatement();

                branches.push_back(
                    std::move(branch)
                );
            }

            expect(TokenType::KW_END);

            expect(
                TokenType::SEMICOLON
            );

            return
                std::make_unique<
                    CaseStatement
                >(
                    std::move(expr),
                    std::move(branches)
                );
        }

        //
        // block
        //

        if (
            current().type
            == TokenType::LBRACE
        ) {

            return parseBlock();
        }

        throw std::runtime_error(
            "Unknown statement"
        );
    }
};

Parser::Parser(
    std::vector<Token> tokens
)
    : tokens(std::move(tokens)) {}

std::unique_ptr<BlockStatement>
Parser::parseProgram() {

    ParserImpl p(tokens, pos);

    p.expect(TokenType::KW_PROGRAM);

    return p.parseBlock();
}
