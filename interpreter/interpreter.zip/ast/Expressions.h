#pragma once

#include "AST.h"

#include <memory>
#include <string>

class LiteralExpression : public Expression {
private:
    Value value;

public:
    explicit LiteralExpression(Value value) : value(value) {}

    Value evaluate(Interpreter&) override {
        return value;
    }
};

class VariableExpression : public Expression {
private:
    std::string name;

public:
    explicit VariableExpression(std::string name)
        : name(std::move(name)) {}

    Value evaluate(Interpreter&) override {
        return Value::makeInt(0);
    }
};

enum class BinaryOp { PLUS, MINUS, MUL, DIV, MOD, LT, GT, EQ, NEQ, AND, OR };

class BinaryExpression : public Expression {
public:
    BinaryExpression(BinaryOp,std::unique_ptr<Expression>,std::unique_ptr<Expression>) {}
    Value evaluate(Interpreter&) override { return Value::makeInt(0); }
};

enum class UnaryOp { PLUS, MINUS, NOT };

class UnaryExpression : public Expression {
public:
    UnaryExpression(UnaryOp,std::unique_ptr<Expression>) {}
    Value evaluate(Interpreter&) override { return Value::makeInt(0); }
};
