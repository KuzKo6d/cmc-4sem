#pragma once

#include "Expressions.h"

#include <memory>
#include <vector>

class BlockStatement : public Statement {
private:
    std::vector<std::unique_ptr<Statement>> statements;

public:
    void add(std::unique_ptr<Statement> stmt) {
        statements.push_back(std::move(stmt));
    }

    void execute(Interpreter& interpreter) override {
        for (auto& stmt : statements) {
            stmt->execute(interpreter);
        }
    }
};
